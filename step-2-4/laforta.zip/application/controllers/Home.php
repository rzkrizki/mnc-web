<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Home extends CI_Controller
{

	public function __construct()
	{
		parent::__construct();
	}

	public function index()
	{
		init_view('home');
	}

	public function submit_data()
	{
		date_default_timezone_set('Asia/Jakarta');

		$post = $this->input->post();

		$data = array(
			'name' => $post['name'],
			'phone' => $post['phone'],
			'email' => $post['email'],
			'date_created' => date('Y-m-d H:i:s')
		);

		$result = $this->db->insert('data', $data);

		if($result){
			$data['results'] = $data;
			$data['message'] = 'Data berhasil dikirm';
			$data['status'] = 200; 
		}else{
			$data['results'] = [];
			$data['message'] = 'Data gagal dikirm';
			$data['status'] = 500; 
		}

		echo json_encode($data);
	}

}