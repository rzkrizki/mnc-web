<section id="section-1">
    <div class="banner-1">
        <div class="container h-100" class="content_banner">
            <div class="row align-items-center content">
                <div class="col-12 text-center">
                    <h1 class="title" id="title-section-1">LAFORTA</h1>
                    <p class="sub-title" id="sub-title-section-1">Rekomendasi Boyke Dian Nugraha, Resmi BPOM, Sertifikasi Halal MUI</p>
                </div>
            </div>
        </div>
    </div>
</section>

<section id="section-2">
    <div class="banner-2">
        <div class="row align-items-center" id="col-section-2">
            <div class="col-12 text-center" id="col-section-2-1">
                <font id="wa-section-2">WA: 0812-8148-1985</font>
                <h1 class="title" id="title-section-2">LAFORTA Benar-benar KUAT!</h1>
                <p class="sub-title" id="sub-title-section-2">Laforta Andalan Para Pria. </p>
            </div>
            <div class="col-md-8" id="col-section-2-2">
                <div class="d-flex justify-content-center">
                    <iframe id="video-section-2" src="https://www.youtube.com/embed/m9AirUmjjQc" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
                </div>
            </div>
            <div class="col-md-3 text-center" id="col-section-2-3">
                <h4 id="font-1-section-2-3">LAFORTA Rekomendasi Resmi Boyke</h4>
                <strong><span id="font-2-section-2-3">Aman dikonsumsi, Resmi BPOM, Sertifikasi Halal</span></strong>
                <br><br>
                <p id="font-3-section-2-3">Pesan Sekarang</p>
                <a href="https://api.whatsapp.com/send?phone=6281281481985&text=Halo%2C%20mohon%20info%20LAFORTA.%20Bagaimana%20cara%20order%3F" target="_blank" class="btn" id="btn-section-2" role="button">
                    <strong>
                        <i aria-hidden="true" class="fab fa-whatsapp"></i> </span>
                        <span class="elementor-button-text">Pesan LAFORTA</span>
                    </strong>
                </a>
            </div>
        </div>
        <div class="spacer"></div>
    </div>
</section>

<section id="section-3">
    <div class="container-xl">
        <div class="row section-3-1 p-5">
            <div class="container">
                <div class="mx-auto rounded container-section-3">
                    <div class="p-2 text-center">
                        <h3 class="title title-section-3">Keunggulan LAFORTA</h3>
                    </div>
                </div>
                <div id="content-section-3-1">
                    <div class="row">
                        <div class="col-md-12">
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="row">
                                        <div class="col-md-5">
                                            <img src="<?= base_url() ?>assets/image/check-circle.png" alt="Check Circle" style="width: 80%;">
                                        </div>
                                        <div class="col-md-7">
                                            <h4 class="title-grey mt-4 title-section-3">RESMI BPOM</h4>
                                            <p class="sub-title-grey mt-3" id="sub-title-section-3">Laforta resmi terdaftar di BPOM dengan Nomor: POM RI MD 869031021367</p>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="row">
                                        <div class="col-md-5">
                                            <img src="<?= base_url() ?>assets/image/check-circle.png" alt="Check Circle" style="width: 80%;">
                                        </div>
                                        <div class="col-md-7">
                                            <h4 class="title-grey mt-4 title-section-3">REKOMENDASI BOYKE</h4>
                                            <p class="sub-title-grey mt-3" id="sub-title-section-3">LAFORTA Produk Resmi Rekomendasi Boyke Dian Nugraha</p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="row mt-5">
                        <div class="col-md-12">
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="row">
                                        <div class="col-md-5">
                                            <img src="<?= base_url() ?>assets/image/check-circle.png" alt="Check Circle" style="width: 80%;">
                                        </div>
                                        <div class="col-md-7">
                                            <h4 class="title-grey mt-4 title-section-3">SERTIFIKASI HALAL MUI</h4>
                                            <p class="sub-title-grey mt-3" id="sub-title-section-3">LAFORTA mendapat sertifikasi Halal MUI No: 17120041520918</p>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="row">
                                        <div class="col-md-5">
                                            <img src="<?= base_url() ?>assets/image/check-circle.png" alt="Check Circle" style="width: 80%;">
                                        </div>
                                        <div class="col-md-7">
                                            <h4 class="title-grey mt-4 title-section-3">AMAN DIKONSUMSI</h4>
                                            <p class="sub-title-grey mt-3" id="sub-title-section-3">LAFORTA merupakan produk pria yang aman dikonsumsi dan tidak membuat ketergantungan.</p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="mt-5">
                    <div class="mx-auto rounded container-section-3">
                        <div class="p-2 text-center">
                            <h3 class="title title-section-3">Kandungan LAFORTA</h3>
                        </div>
                    </div>
                    <div id="content-section-3-2">
                        <p class="paragraf-section-3-1">Suplemen extract Ginseng Putih dan buah Persik, berbentuk serbuk dalam kemasan sachet.</p>
                        <p class="mt-2 paragraf-section-3-1"><strong>Bubuk Persik :</strong> mempercepat penyembuhan luka, memelihara ketajaman penglihatan, melancarkan pencernaan, menjaga berat badan ideal, baik untuk sistem saraf dan neurotransmiter di otak, memperkuat sistem imunitas dan daya tahan tubuh, menguatkan tulang dan gigi, menjaga kepadatan tulang, dan mencegah terjadinya osteoporosis, berperan dalam berbagai proses metabolisme, membantu menenangkan sakit perut, serta meredakan diare dan perut bergas, mencegah anemia </p>
                        <p class="mt-2 paragraf-section-3-1"><strong>Dextrosa Monohidrat.</strong></p>
                        <p class="mt-2 paragraf-section-3-1">Dextrose yang masuk ke dalam tubuh akan menjadi bahan bakar bagi sel tubuh untuk menciptakan energi, sehingga berguna bagi sel tubuh untuk menjalankan fungsi sebagaimana mestinya</p>
                        <p class="mt-2 paragraf-section-3-1"><strong>Asam Askorbat.</strong></p>
                        <p class="mt-2 paragraf-section-3-1">Asam askorbat adalah nama lain dari vitamin C. Jenis vitamin larut air ini merupakan salah satu vitamin paling dibutuhkan oleh tubuh. Fungsi asam askorbat adalah sebagai antioksidan dan meningkatkan sistem imun.</p>
                    </div>
                </div>
                <div class="mt-5">
                    <div class="mx-auto rounded container-section-3">
                        <div class="p-2 text-center">
                            <h3 class="title title-section-3">Manfaat LAFORTA</h3>
                        </div>
                    </div>
                    <div id="content-section-3-2">
                        <p class="paragraf-section-3-2">Manfaat LAFORTA antara lain:</p>
                        <p class="mt-2">
                        <ul class="no-bullets paragraf-section-3-2">
                            <li class="mt-3">1. Meningkatkan Hormon Testosteron dan memperkuat Organ Reproduksi Pria</li>
                            <li class="mt-3">2. Meningkatkan Stamina, Energi, Libido, Performa Seksual Pria dan Imunitas</li>
                            <li class="mt-3">3. Meringankan Stress sehingga badan terasa lebih rileks saat berhubungan intim</li>
                            <li class="mt-3">4. Menurunkan Kolesterol dan Mencegah terjadinya serangan jantung</li>
                            <li class="mt-3">5. Meningkatkan Kesehatan Fisik Stamina & Kekuatan tubuh</li>
                            <li class="mt-3">6. Melancarkan Sirkulasi Darah, sebagai Anti Oksidan & Anti Inflamasi</li>
                            <li class="mt-3">7. Meningkatkan Kualitas Sperma</li>
                            <li class="mt-3">8. Meningkatkan Kekuatan Otot</li>
                        </ul>
                        </p>
                        <p class="paragraf-section-3-2-1 mt-5">Disclaimer: *) Hasil setiap orang bisa berbeda-beda tergantung usia, metabolisme tubuh, history penyakit, dan lain-lain.</p>
                    </div>
                </div>
                <div class="mt-5">
                    <div class="mx-auto rounded container-section-3">
                        <div class="p-2 text-center">
                            <h3 class="title title-section-3">Cara Minum LAFORTA</h3>
                        </div>
                    </div>
                    <div id="content-section-3-3">
                        <p class="paragraf-section-3-3"><strong>CARA MINUM</strong></p>
                        <p class="paragraf-section-3-3">LAFORTA efektif diminum tanpa dicampur dengan air. Tuangkan serbuknya langsung dibawah lidah, diamkan beberapa menit, lalu telan perlahan.</p>
                        <p class="paragraf-section-3-3">LAFORTA BAGUS DIMINUM SAAT PERUT KOSONG Agar penyerapannya maksimal. </p>
                        <ul class="paragraf-section-3-2">
                            <li class="mt-3">PAGI Jam 05.00-09.00 atau</li>
                            <li class="mt-3">SORE Jam 17.00-19.00</li>
                            <li class="mt-3">LAFORTA akan bereaksi dengan halus, sekitar 4-8 jam setelah diminum</li>
                            <li class="mt-3">Efeknya bisa bertahan sekitar 2-3 hari</li>
                            <li class="mt-3">Anjuran Konsumsi : Seminggu 2-3 kali</li>
                        </ul>
                    </div>
                </div>
                <div class="mt-5">
                    <div class="mx-auto rounded container-section-3">
                        <div class="p-2 text-center">
                            <h3 class="title title-section-3">Testimoni LAFORTA</h3>
                        </div>
                    </div>
                    <div class="d-flex justify-content-center mt-3">
                        <iframe id="video-section-3" src="https://www.youtube.com/embed/RbS_qs3_6lE" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
                    </div>
                    <div class="d-flex justify-content-center mt-3">
                        <div class="mt-3">
                            <center><img src="<?= base_url() ?>assets/image/testi-1.jpg" class="img-fluid" alt="Testimony 1" id="img-section-3-1"></center>
                        </div>
                    </div>
                    <div class="row mt-5">
                        <div class="col-md-4">
                            <img src="<?= base_url() ?>assets/image/testi-2.jpg" class="img-fluid" alt="Testimony 2" width="100%">
                        </div>
                        <div class="col-md-4">
                            <img src="<?= base_url() ?>assets/image/testi-3.jpg" class="img-fluid" alt="Testimony 3" width="100%">
                        </div>
                        <div class="col-md-4">
                            <img src="<?= base_url() ?>assets/image/testi-4.jpg" class="img-fluid" alt="Testimony 4" width="100%">
                        </div>
                    </div>
                    <div class="row mt-3">
                        <div class="col-md-4">
                            <img src="<?= base_url() ?>assets/image/testi-5.jpg" class="img-fluid" alt="Testimony 5" width="100%">
                        </div>
                        <div class="col-md-4">
                            <img src="<?= base_url() ?>assets/image/testi-6.jpg" class="img-fluid" alt="Testimony 6" width="100%">
                        </div>
                        <div class="col-md-4">
                            <img src="<?= base_url() ?>assets/image/testi-7.jpg" class="img-fluid" alt="Testimony 7" width="100%">
                        </div>
                    </div>
                </div>
                <div class="mt-5">
                    <div class="mx-auto rounded container-section-3">
                        <div class="p-2 text-center">
                            <h3 class="title">Harga LAFORTA</h3>
                        </div>
                    </div>
                    <div class="d-flex justify-content-center mt-3">
                        <div class="mt-3">
                            <center><img src="<?= base_url() ?>assets/image/harga.jpg" class="img-fluid" alt="Harga Laforta" width="100%"></center>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<section id="section-4">
    <div class="container-xl">
        <div class="row section-4-1 p-5">
            <div class="container mt-3">
                <div class="text-center">
                    <h3 class="title title-section-4">Dapatkan LAFORTA Harga PROMO Hari ini:</h3>
                    <p class="paragraf-section-4-1 mt-3">
                        <del class="title">Rp. 600.000,-</del>
                        <strong style="color: #43bbe5;">Rp. 450.000,-</strong>
                    </p>
                    <p class="paragraf-section-4-2 mt-5">
                        1 box LAFORTA isi 10 sachet
                    </p>
                    <p class="paragraf-section-4-2 mt-5">
                        HATI-HATI dengan Penawaran Harga MURAH dibawah 450.000,- Waspada Barang PALSU! Jangan Pertaruhkan kesehatan Anda dengan membeli barang murah!
                    </p>
                    <a href="https://api.whatsapp.com/send?phone=6281281481985&text=Halo%2C%20mohon%20info%20LAFORTA.%20Bagaimana%20cara%20order%3F" target="_blank" class="btn" id="btn-section-4" role="button">
                        <strong>
                            <i aria-hidden="true" class="fas fa-hand-o-right"></i> </span>
                            <span class="elementor-button-text">Klik untuk pemesanan</span>
                        </strong>
                    </a>
                    <p class="paragraf-section-4-3 mt-4">
                        Kapan lagi Anda bisa menghemat Rp 150.000,- untuk pemesanan hari ini. Silahkan klik tombol di atas untuk memesan produk LAFORTA dan kami akan segera proses pesanan Anda.
                    </p>
                    <div class="mt-4">
                        <img src="<?= base_url() ?>assets/image/daftar-bank.jpg" alt="Daftar Bank" id="img-section-4-1">
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<section id="section-5">
    <div class="container-xl">
        <div class="row section-4-1 p-5">
            <div class="container mt-3">
                <div class="text-center">
                    <div class="mt-3">
                        <img src="<?= base_url() ?>assets/image/cod.png" alt="COD Image" id="img-section-5-1">
                    </div>
                    <div class="mt-5">
                        <h1 class="title paragraf-section-5-1">Rasakan Sensasinya Bersama Istri Anda!</h1>
                    </div>
                    <div class="mt-5">
                        <h1 class="title paragraf-section-5-1">Bikin Si Dia Tersenyum Puass!</h1>
                    </div>
                    <div class="mt-5">
                        <img src="<?= base_url() ?>assets/image/testi-boyke.jpg" alt="Testi Dr.Boyke" id="img-section-5-2">
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<section id="section-6">
    <div class="container-xl">
        <div class="row section-5-1 p-5">
            <div class="container mt-3">
                <div class="text-center">
                    <div class="mt-3">
                        <h1 class="title paragraf-section-6-1">Kekuatan Kejantanan Pria!</h1>
                    </div>
                    <div class="mt-3">
                        <h1 class="title paragraf-section-6-2">Pesan Sekarang</h1>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<section id="section-7">
    <div class="container-sm">
        <div class="row section-7-1 p-2">
            <div class="container-xl mx-auto">
                <div class="text-center">
                    <div class="col-md-12">
                        <div class="mt-3">
                            <div class="form-group">
                                <label for="name" class="title-section-7"><strong>NAMA</strong></label>
                                <input type="text" class="form-control" id="name" placeholder="Atta Halilintar">
                            </div>
                        </div>
                        <div class="mt-3">
                            <div class="form-group">
                                <label for="phone"><strong>HP</strong></label>
                                <div class="row">
                                    <div class="col-3">
                                        <input type="text" class="form-control" id="format" value="62" readonly>
                                    </div>
                                    <div class="col-9">
                                        <input type="number" class="form-control" id="phone" value="81234567890">
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="mt-3">
                            <div class="form-group">
                                <label for="email"><strong>E-mail</strong></label>
                                <input type="text" class="form-control" id="email" placeholder="budi@gmail.com">
                            </div>
                        </div>
                        <div class="mt-3">
                            <button class="btn btn-success btn-block" onclick="checkData()"><strong>SUBMIT</strong></button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<section id="section-8">
    <div class="container-sm">
        <div class="row section-8-1 p-2">
            <div class="container">
                <div class="text-center">
                    <div class="mt-3">
                        <img src="<?= base_url() ?>assets/image/license-bpom.jpg" alt="License BPOM" class="img-license">
                        <img src="<?= base_url() ?>assets/image/license-mui.jpg" alt="License MUI" class="img-license">
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<section id="section-9" class="fixed-bottom">
    <div class="container-sm">
        <div class="row section-9-1 p-2">
            <div class="container">
                <div class="text-center">
                    <a href="https://api.whatsapp.com/send?phone=6281281481985&amp;text=Halo%2C%20mohon%20info%20LAFORTA.%20Bagaimana%20cara%20order%3F" target="_blank" class="btn" id="btn-section-9" role="button">
                        <strong>
                            <span class="elementor-button-text" id="cta-bottom"></span>
                            <i aria-hidden="true" class="fab fa-whatsapp"></i> </span>
                        </strong>
                    </a>
                </div>
            </div>
        </div>
        <button onclick="topFunction()" id="btn-back-to-top" title="Go to top"><i class="fa fa-chevron-up"></i></button>
    </div>
</section>


<script>
    setInterval(function time() {
        var d = new Date();
        var hours = 24 - d.getHours();
        var min = 60 - d.getMinutes();
        if ((min + '').length == 1) {
            min = '0' + min;
        }
        var sec = 60 - d.getSeconds();
        if ((sec + '').length == 1) {
            sec = '0' + sec;
        }
        $('#cta-bottom').html(hours + ':' + min + ':' + sec)
    }, 1000);

    function checkData() {
        var name = $('#name').val()
        var phone = $('#phone').val()
        var phoneTwoCharacter = phone.substring(0, 2);
        var phoneOneCharacter = phone.substring(0, 1);
        var email = $('#email').val()
        if (name != '' && phone != '' && phoneTwoCharacter != '62' && phoneOneCharacter == '8' && email != '') {
            submitData()
        } else {
            if (name == '') {
                getWarning('Nama tidak boleh kosong')
            } else if (phone == '') {
                getWarning('HP tidak boleh kosong')
            } else if (phoneTwoCharacter == '62') {
                getWarning('Nomor HP Tidak Valid')
            } else if (phoneOneCharacter != '8') {
                getWarning('Nomor HP Tidak Valid')
            } else {
                getWarning('Email tidak boleh kosong')
            }
        }
    }

    function submitData() {
        var name = $('#name').val()
        var phone = '62' + $('#phone').val()
        var email = $('#email').val()
        $.ajax({
            url: "<?= base_url('home/submit_data') ?>",
            type: "POST",
            dataType: "json",
            data: {
                'name': name,
                'phone': phone,
                'email': email,
            },
            success: function(response) {
                if (response.status == 500) {
                    getError(response.message)
                } else {
                    getSuccess(response.message, response.results)
                }
            },
            error: function(e) {
                getError(e)
            }
        })
    }

    function clearForm() {
        $('#name').val('')
        $('#phone').val('')
        $('#email').val('')
    }

    function sendtoWhatsApp(response) {
        var nameEncode = encodeURI(response.name)
        window.open('https://api.whatsapp.com/send?phone=6281281481985&text=Halo%20Saya%20' + nameEncode + '%2C%20mohon%20info%20LAFORTA.%20Bagaimana%20cara%20order%3F')
    }

    function getSuccess(msg, results) {
        Swal.fire({
            position: 'center',
            icon: 'success',
            title: msg,
            showConfirmButton: true,
        }).then((result) => {
            if (result.isConfirmed) {
                sendtoWhatsApp(results)
                clearForm()
            }
        })
    }

    function getWarning(msg) {
        Swal.fire({
            icon: 'warning',
            title: 'Oops...',
            text: msg
        })
    }

    function getError(msg) {
        Swal.fire({
            icon: 'error',
            title: 'Oops...',
            text: msg
        })
    }
</script>